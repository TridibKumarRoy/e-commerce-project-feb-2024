import React from "react";
import { ArrowIcon, HomeIcon } from "../assets/SVG/Icons";
import { Link } from "react-router-dom";
import axios from "axios";
import { axiosInstance } from "../utils/axios";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

const PRODUCT_CATEGORY = [
  { label: "Parts & Accessories" },
  { label: "Outfit" },
  { label: "Wheels and Tyres" },
  { label: "Comfort and Convenience" },
  { label: "Performance Upgrades" },
];

const AddProduct = () => {
  const handleAdd = async (values, { setSubmitting }) => {
    try {
      const formData = new FormData();
      formData.append("file", values.image);
      formData.append("upload_preset", "fhsuyvig");

      const response = await axios.post(
        "https://api.cloudinary.com/v1_1/dljm2aypb/image/upload",
        formData
      );

      const { data } = await axiosInstance.put("/products/new", {
        type: "profile",
        image: response?.data?.url,
        imageId: response?.data?.public_id,
        name: values.name,
        category: values.category,
        price: values.price,
        stocks: values.stocks,
      });

      console.log(data);
    } catch (error) {
      console.log(error);
    } finally {
      setSubmitting(false);
    }
  };

  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Product Name is required"),
    category: Yup.string().required("Category is required"),
    price: Yup.number().required("Price is required").positive("Price must be positive"),
    stocks: Yup.number().required("Stocks is required").integer("Stocks must be an integer").min(0, "Stocks cannot be negative"),
  });

  return (
    <div className="container">
      <div className="page-inner">
        <div className="page-header">
          <h3 className="fw-bold mb-3">Add Product</h3>
          <ul className="breadcrumbs mb-3 d-flex align-items-center">
            <li className="nav-home">
              <Link to="/dashboard">
                <HomeIcon />
              </Link>
            </li>
            <li className="separator">
              <ArrowIcon />
            </li>
            <li className="nav-item">
              <Link to="/dashboard/products">Products</Link>
            </li>
            <li className="separator">
              <ArrowIcon />
            </li>
            <li className="nav-item">
              <a href="#">Add Product</a>
            </li>
          </ul>
        </div>

        <div className="row">
          <div className="col-md-12">
            <Formik
              initialValues={{ name: "", category: "", price: "", stocks: "" }}
              validationSchema={validationSchema}
              onSubmit={handleAdd}
            >
              {({ isSubmitting, setFieldValue }) => (
                <Form className="card">
                  <div className="card-header">
                    <div className="card-title"></div>
                  </div>
                  <div className="card-body">
                    <div className="row">
                      <div className="col-md-6">
                        <div className="form-group">
                          <label htmlFor="name">Product Name</label>
                          <Field type="text" className="form-control" id="name" name="name" placeholder="Enter product name" />
                          <ErrorMessage name="name" component="div" className="text-danger" />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-group">
                          <label htmlFor="category">Category</label>
                          <Field as="select" className="form-control" name="category">
                            <option disabled={true} value="">Select Category</option>
                            {PRODUCT_CATEGORY.map((item, i) => (
                              <option value={item.label} key={i}>
                                {item.label}
                              </option>
                            ))}
                          </Field>
                          <ErrorMessage name="category" component="div" className="text-danger" />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-group">
                          <label htmlFor="price">Price</label>
                          <Field type="text" className="form-control" id="price" name="price" placeholder="Enter Price" />
                          <ErrorMessage name="price" component="div" className="text-danger" />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="form-group">
                          <label htmlFor="stocks">Stocks</label>
                          <Field type="text" className="form-control" id="stocks" name="stocks" placeholder="Enter Stocks" />
                          <ErrorMessage name="stocks" component="div" className="text-danger" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="card-action d-flex gap-3">
                    <button type="submit" className="btn btn-success" disabled={isSubmitting}>
                      Submit
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddProduct;
