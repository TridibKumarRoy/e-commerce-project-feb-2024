import React, { useContext } from "react";
import { isValidURL, sliceText } from "../utils/helper";
import { ProductContext } from "../context/ProductContext";
import { DeleteIcon, EditIcon } from "../assets/SVG/Icons";
import { Link } from "react-router-dom";

const Products = () => {
  const { products } = useContext(ProductContext);
  return (
    <>
      <div class="container">
        <div class="page-inner">
          <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
            <div>
              <h3 class="fw-bold mb-3">Products</h3>
            </div>

            <div class="ms-md-auto py-2 py-md-0">
              <Link to="/dashboard/add-product" class="btn btn-primary btn-round">
                Add Product
              </Link>
            </div>
          </div>

          <div class="row">
            <div class="col-12">
              <div class="card card-round">
                <div class="card-header d-flex justify-content-between">
                  <div class="card-head-row card-tools-still-right">
                    <h4 class="card-title">All Products</h4>
                  </div>

                  <div>
                    <input
                      type="search"
                      class="form-control"
                      placeholder="Search..."
                    />
                  </div>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-12">
                      <div class="table-responsive table-hover table-sales">
                        <table class="table">
                          <thead>
                            <tr>
                              <th style={{ minWidth: 300 }}>Name</th>
                              <th style={{ minWidth: 220 }}>Category</th>
                              <th style={{ minWidth: 150 }} class="text-end">
                                In Stock
                              </th>
                              <th class="text-end">Price</th>
                              <th class="text-end">Rating</th>
                              <th class="text-center">Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {products?.map((item, i) => (
                              <tr key={i}>
                                <td>
                                  <div className="d-flex">
                                    <div>
                                      <img
                                        width={40}
                                        height={40}
                                        style={{ borderRadius: "50%" }}
                                        src={
                                          isValidURL(item?.images[0]?.url)
                                            ? item?.images[0]?.url
                                            : "https://i.pinimg.com/originals/c0/27/be/c027bec07c2dc08b9df60921dfd539bd.webp"
                                        }
                                        alt="indonesia"
                                      />
                                    </div>

                                    <div class="info-user ms-3">
                                      <div class="username">{item?.name}</div>
                                      <div
                                        class="status"
                                        style={{ color: "gray" }}
                                      >
                                        {sliceText(item?.description, 100)}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td>{item?.category}</td>
                                <td
                                  class={`text-end  ${
                                    item?.Stock ? "text-success" : "text-danger"
                                  }`}
                                >
                                  {item?.Stock}
                                </td>
                                <td class="text-end">
                                  ₹{item?.price?.toFixed(2)}
                                </td>
                                <td class="text-end">{item?.ratings}</td>
                                <td class="d-flex gap-3">
                                  <button className="btn btn-warning">
                                    <EditIcon />
                                  </button>
                                  <button className="btn btn-danger">
                                    <DeleteIcon />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Products;
