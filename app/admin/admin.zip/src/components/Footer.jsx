import React from "react";

const Footer = () => {
  return (
    <footer class="footer">
      <div class="container-fluid d-flex justify-content-between">
       <div></div>
        <div class="copyright">
          2024, @copyright bhoom
        </div>
        <div></div>
      </div>
    </footer>
  );
};

export default Footer;
